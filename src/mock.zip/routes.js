import LoginView from './Page/LoginView.vue';
// import RegistrationPage from './Page/RegistrationPage.vue';
// import Table from './Page/Table.vue';

// import dashtata from './Page/tata_aig.vue'

// // MainDashboard
import MainDashboard from './Page/Dashbord/MainDashboard.vue'

// import thekpi from './Page/thekpidash.vue'

// import the_P_kpi from './Page/the_producer_kpi.vue'

// import bancaDash from './Page/Dashbord/bancamaindash.vue'

// import thedash from './Page/Dashbord/dashNEW.vue'

// // pdf view-in

// import pdfview from './Page/pdfview.vue'

// //resource center content creation sub-cat page

// import resourcentermaster from './Page/Customerpitch/resourceSubCat.vue'

// // Location page

// import AttendanceLocation from './Page/LocationPage/AttendaceLocation.vue'
// import GlobleLocation from './Page/LocationPage/SetLocation/GlobleSettingLocation.vue'

// // Testing google maps
// import Maps from './Page/LocationPage/Maps.vue'

// // logs 
// import adminlogs from './Page/adminlogs.vue';

// // proposal Salman
// import Proposal from './Page/Proposal/proposal.vue';
// import proposalAll from './Page/Proposal/proposalAll'
// import proposalOpen from './Page/Proposal/propsalOpen.vue';
// import proposalPass from './Page/Proposal/proposalPass.vue';
// import ProposalReject from './Page/Proposal/propsalreject.vue';
// import proposalArchieve from './Page/Proposal/proposalArchieve.vue';
// import propTab from './component/propTab.vue';

// import proposalSumm from './Page/Proposalqc/ProposalSumm.vue'
// import propSummCompo from './component/prop-summ-compo.vue'

// // proposal admin page shoaib
// import ProposalMaster from './Page/Proposalqc/ProposalMaster.vue'
// import ProposalTab from './Page/Proposalqc/ProposalTab.vue';
// import ProposalBi from './Page/Proposalqc/ProposalBi.vue';
// import ProposalRecipting from './Page/Proposalqc/ProposalRecipting.vue'
// import Proposalfulfilment from './Page/Proposalqc/Proposalfulfilment.vue'

// //proposal admin document upload ashraf
// import ProposalDocUpload from './Page/Proposalqc/ProposalDocumentUpload.vue'

// //FNA ashraf new page
// import helpToknowbetter from './Page/FNA/helpToKnowBetter.vue'
// import AddChild from './Page/FNA/AddChild.vue'

// // import AnalysisEducation from './Page/FNA/AnalysisEducation1.vue'
// import RiskProfile from './Page/FNA/RiskProfilingQuestion/RiskProfilequestion1.vue'
// import HigherEducation from './Page/FNA/HigherEducation.vue'
// //FNA Shoaib planning and achieving
// import PlanningAndAchieving from './Page/FNA/PlanningAndAchieving.vue'
// // import AnalysisEducation1 from './Page/FNA/AnalysisEducation1.vue'
// // import Slick from './Page/FNA/slick.vue'
// import RiskQuotient from './Page/FNA/RiskQuotient.vue'
// // MasterPage form
// import MasterPageForm from './MasterPage/MasterForm.vue'
// import MasterForm from './MasterPage/Rolemaster.vue'
// import Testimonial from './Page/FNA/Testimonial.vue'
// import newpresentation from './Page/Customerpitch/newpresentationclone.vue'


// import Channel from './MasterPage/channel.vue'
// import Rolemaster from './MasterPage/Rolemaster.vue'
// import productMaster from './MasterPage/ProductMaster.vue'
// import UserManagement from './MasterPage/user_mngmnt.vue'
// import CityCountry from './MasterPage/CityCountry.vue'

// import Campaign from './MasterPage/campaignMaster.vue'
// import SubCampaign from './MasterPage/subCampaign.vue'
// import AffiliateMaster from './MasterPage/AffiliateMaster.vue'
// import DocumentMaster from './MasterPage/DocumentMaster.vue'
// import IncomeMaster from './MasterPage/IncomeMaster.vue'
// import StateCityMaster from './MasterPage/stateCityMaster.vue'


// import UploadBill from './Page/uploadBill.vue'

// // Actity Upload @ashraf
// import ActivityUpload from './Page/ActivityUpload/ActivityUpload.vue'
// import ActivityLeadUpload from './Page/ActivityUpload/ActivityLeadUpload.vue'
// import ActivityReport from './Page/ActivityUpload/ActivityReport.vue'
// import ActivityTracking from './Page/ActivityUpload/activityTracking.vue'

// // Report BHavik
// import Reports from './Reports/reports.vue'
// import CustomReports from './Reports/customReport.vue'
// import Reconreports from './Reports/reconReports.vue'

// // Customer pitch @shoaib
// import PresentationPitch from './Page/Customerpitch/PresentationPitch.vue'
// import TestimonialsPitch from './Page/Customerpitch/TestimonialsPitch.vue'
// import ProductPitch from './Page/Customerpitch/ProductPitch.vue'
// // Attendance Bhavik
// import AttendanceMaster from './MasterPage/AttendanceMaster.vue'

// // Advisors pitch
// import AdvisorAboutUs from './Page/AdvisorPitch/Aboutus.vue'
// import AdvisorBenefits from './Page/AdvisorPitch/Benefits.vue'
// import AdvisorSuccessStory from './Page/AdvisorPitch/SuccessStory.vue'

// // user Dashbord shoaib
// import UserDashbord from '../src/Page/Dashbord/UserDashbord.vue'
import UserManagemnt from './component/userMangmntCompo.vue'

// import NewDashboard from '../src/Page/Dashbord/newDashboard.vue'

// new Product pitch
// import ProductNew from './Page/Customerpitch/ProductNew.vue'
// DATABASE CLEAR
// import dbClear from './Page/DBClear.vue'
// import InsuranceAdmin from './Page/InsuranceAdmin'
// import Traveldetails from './Page/Traveldetails'

// import Pet from './Page/BOD/Pet.vue'
// import Dengue from './Page/BOD/Dengue.vue'

// import InformationTab from './Page/InformationTab.vue'
// import travelInfoTab from './Page/travelInfoTab.vue'
// import Petinfo from './Page/BOD/Petdetails.vue'
// import Denguedetails from './Page/BOD/Denguedetails.vue'

// Access control/role management
// import AccessControl from './Page/AccessControl.vue'

// import NewAccessControl from './Page/NewAccessControl.vue'

// import Demo from './Page/NewDemo.vue'

// import Productlist from './Page/Customerpitch/Productlist.vue'

// USER ATTENDANCE
// import Userattendance from './Page/Dashbord/UserAttendance.vue'

// EXTRA PAGE FOR USER
// import Branchdetails from './Page/BranchDetails.vue'
// import pocdashboard from './Page/PocDashboard/pocdashboard.vue'
// import Carupload from './Page/ActivityUpload/POC/CarUpload'
// import Zonemaster from './MasterPage/Zonemaster.vue'
// import Hierarchymaster from './MasterPage/Heirarchymaster.vue'
// import leadTab from './Page/ActivityUpload/leadCreate/leadtab.vue'
// import Status from './Page/ActivityUpload/leadCreate/status.vue'
// import Designation from './MasterPage/Designationmaster.vue'


//bancamaster
// import bankmaster from './MasterPage/bankMaster.vue'

// import bancaMaster from './MasterPage/bancaBranchMaster.vue'

/**
 * Poc-Product module routes
 */

// import NewBlog from './Page/poc-blog/create-blog'
// import BlogMaster from './Page/poc-blog/blog-master'

// import Leaddetailstabs from './component/vtabs/vtabs.vue'

// import PersonalD from './component/vtabs/personallead.vue'

// import ContactD from './component/vtabs/contactlead.vue'

// import ProD from './component/vtabs/professionallead.vue'

// import ProposedD from './component/vtabs/proposedproduct.vue'

// import ExistingD from './component/vtabs/existinglead.vue'

// import Leadhistory from './component/Tabs/leadhistory.vue'

// import Leadstatus from './component/Tabs/newleadstatus.vue'

// import Lmaster from './component/Tabs/masterleadpage.vue'

// import Mailgun from './component/bulkmailgun.vue'

// import Sourcemaster from './MasterPage/SourceMaster.vue'

import RCCatMaster from './MasterPage/ResourceCenterCatMaster.vue'

// import Occupmaster from './MasterPage/Occupationmaster.vue'

// import smaster from './MasterPage/smaster.vue'

// import campmaster from './MasterPage/campmaster.vue'

// import Policydetails from './component/policydetails.vue'

// import Customerdetails from './component/customerdetails.vue'

// import existdetails from './component/existingDetails.vue'

// import accesstest from './Page/accesstest.vue';

// import newadminlogs from './Page/newadminlogs.vue'

// import cd from './component/admin_creation.vue'

// import mainkpicat from './Page/kpimaincat.vue';

// import mainkpi_subcat from './Page/kpimain_sub_cat.vue'

// import map from './Page/kpi_map.vue'

// import q_map from './Page/mapit_quarter.vue'

// import kpiDashQuarter from './Page/kpiDash-quarter.vue'

// import clubMaster from './MasterPage/clubMaster.vue'
// import partneractiviytracker from './MasterPage/Reportmaster/partnerActivitytracker.vue'
// import Commitmnetactivitytracker from './MasterPage/Reportmaster/CommitmentActivityTracker.vue'
// import recruitmnetactivitytracker from './MasterPage/Reportmaster/RecruitmentActivityTracker.vue'

// import customnotification from './Page/Customnotification.vue'

// import TataData from './Page/TataData.vue'

// // Reconciliation Project Routes

// import reconcilation from './Page/Reconcilation/Reconcilationview.vue'
// import manualreconciledcases from './Page/Reconcilation/Manualreconciledcases.vue'
// import reconcilationrule from './Page/Reconcilation/Reconcilationrule.vue'
// import advancesearcepage from './Page/Reconcilation/Advancesearch.vue'
// import auditlog from './Page/Auditlog/auditlog.vue'
// import bankaccountmaster from './Page/Bankaccountmaster/bankaccountmaster.vue'

// import datamapping from './Page/DataMapping.vue'
// import reconaccess from './Page/Reconaccess.vue';

// import approvalbucket from './Page/Maker_checker/Approvalbucket.vue'

// RN SCHEDULER
// New Dashboard
// import Dashboard from "./Page/RenewalNotice/NewDashboard.vue"
import RNSchedule from './Page/RNScheduler/RnScheduler.vue'
import RNScheduleStatus from './Page/RNScheduler/RnSchedulerStatus.vue'
import PolicySummary from './Page/RenewalNotice/cv/PolicySummary.vue'
import UploadWarrantiesMop from './Page/RenewalNotice/UploadWarrantiesMop.vue'
import MappingTest from './Page/RenewalNotice/cv/MappingTest.vue'
import UploadCreateMapping from './Page/RenewalNotice/cv/UploadCreateMapping.vue'



// import approvalbucket from './Page/Maker_checker/Approvalbucket.vue'
// import renewalnoticereport from './Page/RenewalNotice/RenewalNoticeReport.vue'

import renewalnoticeregeneration from './Page/RenewalNotice/RenewalNoticeRegeneration.vue'

import renewalNoticeDownload from './Page/RenewalNotice/RenewalNoticeDownload.vue'
import TriggerCCM from './Page/RenewalNotice/TriggerCCM.vue'
import RenewalExtractReport from './Page/RenewalExtract/RenewalExtractReport.vue';
import RenewalModify from './Page/RenewalExtract/RenewalExtractModification.vue';
import MultiplePolicy from './Page/RenewalExtract/MultiplePolicy.vue';
import RenewalNotRegPage from './Page/RenewalNotice/RenewalNoticeRegPage.vue';
// import DownloadReg from './Page/RenewalNotice/DownloadReg.vue';
// import UploadRegneration from './Page/RenewalNotice/UploadRegeneration.vue';
// import PolicyAudittrail from './Page/RenewalNotice/PolicyAuditTrail.vue'
// import ModifyPolicy from './Page/RenewalNotice/ModifySinglePolicy.vue'
import UserManage from './Page/RenewalNotice/UserManagement.vue'
// import SharingRenewalNotice from './Page/RenewalNotice/sharingRenewalNotice.vue'
import viewNotifications from './Page/viewNotifications.vue'
// import InactivePolicy from './Page/InactivePolicy.vue';

// Travel Refered cases
import TravelReferedCases from "./Page/RenewalNotice/TravelReferedCases.vue"

// Aigc 
import PolicySummaryAigc from "./Page/RenewalNotice/AigcPolicySummary.vue"

//job scheduler 
import JobScheduler from './Page/RenewalNotice/JobScheduler'

//create user
import CreateUser from './Page/RenewalNotice/CreateUser'
//RV vs Data rep 
import RvAndDataRep from './Page/RenewalNotice/cv/RvAndDataRep'
import ExcelBucketMovement from './Page/RenewalNotice/cv/ExcelBucketMovement'
import PullDataFromDataRep from './Page/RenewalNotice/cv/PullDataFromDataRep'
import JsonMapping from './Page/RenewalNotice/cv/JsonMapping'

//Download screen
import DownloadReports from './Page/RenewalNotice/cv/DownloadReports';

export const routes = [{

        path: '/maindashboard',
        name: 'MainDashboard',   
        component: MainDashboard
    },
    {
        path:'/notifications',
        name: viewNotifications,
        component: viewNotifications
    },
    
    // {
    //     path:'/reconcilation',
    //     name: reconcilation,
    //     component: reconcilation
    // },
    // {
    //     path:'/InactivePolicy',
    //     name: InactivePolicy,
    //     component: InactivePolicy
    // },
    {
        path:'/usermanagement',
        name: UserManage,
        component: UserManage
    },
    {
        path:'/createuser',
        name: CreateUser,
        component: CreateUser, props: true
    },
    // {
    //     path:'/sharingrenewalnotice',
    //     name: SharingRenewalNotice,
    //     component: SharingRenewalNotice
    // },
    // {
    //     path:'/dashboard',
    //     name: 'Dashboard',
    //     component: Dashboard
    // },
    {
        path:'/rn-scheduler',
        name: 'RNSchedule',
        component: RNSchedule
    },
    {
        path:'/rn-scheduler-status',
        name: 'RNScheduleStatus',
        component: RNScheduleStatus
    },
        {
            path:'/policysummary',
            name: 'PolicySummary',
            component: PolicySummary
        },
        {
            path:'/json-mapping',
            name: 'JsonMapping',
            component: JsonMapping
        },
        // {
        //     path:'/manualreconciledcases',
        //     name: manualreconciledcases,
        //     component: manualreconciledcases
        // },

        // {
        //     path:'/reconcilationrule',
        //     name: reconcilationrule,
        //     component: reconcilationrule
        // },

        // {
        //     path:'/advancesearcepage',
        //     name: advancesearcepage,
        //     component: advancesearcepage
        // },

        
        // {
        //     path:'/approvalbucket',
        //     name: approvalbucket,
        //     component: approvalbucket
        // },

    // {
    //     path:'/renewalnoticereport',
    //     name: renewalnoticereport,
    //     component: renewalnoticereport
    // },

    

    {
        path:'/renewalnoticeregeneration',
        name: renewalnoticeregeneration,
        component: renewalnoticeregeneration
    },

    {
        path:'/renewal-download',
        name: renewalNoticeDownload,
        component: renewalNoticeDownload
    },
    {
        path:'/trigger-ccm',
        name: TriggerCCM,
        component: TriggerCCM
    },

    // {
    //     path:'/policy-audit',
    //     name: PolicyAudittrail,
    //     component: PolicyAudittrail
    // },
    {
        path:'/travelReferedCases',
        name: TravelReferedCases,
        component: TravelReferedCases
    },
    // {
    //     path:'/modifypolicy',
    //     name: ModifyPolicy,
    //     component: ModifyPolicy
    // },
    {
        path:'/RenewalExtractReport',
        name: RenewalExtractReport,
        component: RenewalExtractReport
    },
    // {
    //     path:'/RenewalModify',
    //     name: RenewalModify,
    //     component: RenewalModify
    // },
    // {
    //     path:'/MultiplePolicy',
    //     name: MultiplePolicy,
    //     component: MultiplePolicy
    // },
    {
        path:'/RenewalNotRegPage',
        name: RenewalNotRegPage,
        component: RenewalNotRegPage
    },
    // {
    //     path:'/DownloadReg',
    //     name: DownloadReg,
    //     component: DownloadReg
    // },
    // {
    //     path:'/UploadRegneration',
    //     name: UploadRegneration,
    //     component: UploadRegneration
    // },
    
    // {
    //     path:'/auditlog',
    //     name: auditlog,
    //     component: auditlog
    // },
    // {
    //     path:'/bankaccountmaster',
    //     name: bankaccountmaster,
    //     component: bankaccountmaster
    // },
    

    
    // {
    //     path:'/datamapping',
    //     name: datamapping,
    //     component:datamapping
    // },

    // {
        
    //     path: '/dataImport',
    //     name: 'TataData',
    //     component: TataData
    // },

    // {
    //     path:'/mapit',
    //     name: map,
    //     component: map
    // },

    // {
    //     path:'/customnotification',
    //     name: customnotification,
    //     component: customnotification
    // },

    // {
    //     path:'/qmap',
    //     name: q_map,
    //     component: q_map
    // },


    // {
    //     path:'/mkpisc',
    //     name: mainkpi_subcat,
    //     component: mainkpi_subcat
    // },

    // {
    //     path:'/mkpic',
    //     name: mainkpicat,
    //     component: mainkpicat
    // },

    // {
    //     path: '/dash',
    //     name: 'dashtata',
    //     component: dashtata
    // },
    
    // {
    //     path: '/kpii',
    //     name: 'thekpi',
    //     component: thekpi
    // },
    // {
    //     path: '/kpi-dash-quarter',
    //     name: 'kpiDashQuarter',
    //     component: kpiDashQuarter
    // },
    // {
    //     path: '/club-master',
    //     name: 'clubMaster',
    //     component: clubMaster
    // },
    
    // {
    //     path: '/pkpii',
    //     name: 'the_P_kpi',
    //     component: the_P_kpi
    // },

    // {
    //     path: '/c_d',
    //     name: 'cd',
    //     component: cd
    // },
    
    // {
    //     path: '/bancaDash',
    //     name: 'bancaDash',
    //     component: bancaDash
    // }, 

    // {
    //     path: '/dashb',
    //     name: 'thedash',
    //     component: thedash
    // },

    
    // {
    //     path: '/pocdashboard',
    //     name: 'pocdashboard',
    //     component: pocdashboard
    // },

    // {
    //     path: '/alogs',
    //     name: 'adminlogs',
    //     component: adminlogs
    // },

    // {
    //     path: '/admlogger',
    //     name: 'newadminlogs',
    //     component: newadminlogs
    // },
    
    // {
    //     path: '/partneractiviytracker',
    //     name: 'partneractiviytracker',
    //     component: partneractiviytracker
    // },
    // {
    //     path: '/Commitmnetactivitytracker',
    //     name: 'Commitmnetactivitytracker',
    //     component: Commitmnetactivitytracker
    // },
    // {
    //     path: '/recruitmnetactivitytracker',
    //     name: 'recruitmnetactivitytracker',
    //     component: recruitmnetactivitytracker
    // },
    
    

    /**
     * Date 25/02/2019
     * Khan Usama
     * For POC-Product repliation
     */
    // {
    //     path: '/new_blog',
    //     name: 'NewBlog',
    //     component: NewBlog
    // },
    // {
    //     path: '/blog_master',
    //     name: 'BlogMaster',
    //     component: BlogMaster
    // },

    {
       
        path: '/LoginView',
        name: 'LoginView',
        component: LoginView
    },
    // {
    //     path: '/RegistrationPage',
    //     name: 'RegistrationPage',
    //     component: RegistrationPage
    // },
    // {
    //     path: '/Newdemo',
    //     name: 'Demo',
    //     component: Demo
    // },
    // {
    //     path: '/activityreport',
    //     name: 'activityreport',
    //     component: ActivityReport
    // },

    // {
    //     path: '/pv',
    //     name: 'pdfview',
    //     component: pdfview
        
    // },

    // {
    //     path: '/helptoknowbetter',
    //     name: 'helptoknowbetter',
    //     component: helpToknowbetter
    // },
    // {
    //     path: '/activityUpload',
    //     name: 'activityUpload',
    //     component: ActivityUpload

    // },
    // {
    //     path: '/activityLeadUpload',
    //     name: 'activityLeadUpload',
    //     component: ActivityLeadUpload

    // },

    // {
    //     path: '/planningandachieving',
    //     name: 'PlanningAndAchieving',
    //     component: PlanningAndAchieving


    // },
    // {
    //     path: '/globlelocation',
    //     name: 'GlobleLocation',
    //     component: GlobleLocation


    // },
    // // {
    // //     path: '/analysiseducation',
    // //     name: 'analysiseducation',
    // //     component: AnalysisEducation
    // // },
    // {
    //     path: '/riskprofile',
    //     name: 'riskprofile',
    //     component: RiskProfile
    // },
    
    // {
    //     path: '/testimonial',
    //     name: 'Testimonial',
    //     component: Testimonial
    // },

    // {
    //     path: '/presentation',
    //     name: 'newpresentation',
    //     component: newpresentation
    // },


    // {
    //     path: '/proposaltab',
    //     name: ' ProposalTab',
    //     component: ProposalTab
    // },
    // {
    //     path: '/attendanceLocation',
    //     name: 'attendanceLocation',
    //     component: AttendanceLocation
    // },
    // {
    //     path: '/proposal',
    //     name: 'Proposal',
    //     component: Proposal
    // },
    // {
    //     path: '/proposalopen',
    //     name: 'proposalOpen',
    //     component: proposalOpen
        
    // },
    // {
    //     path: '/proposalAll',
    //     name: 'proposalAll',
    //     component: proposalAll
    // },
    // {
    //     path: '/proposalqcpass',
    //     name: 'proposalPass',
    //     component: proposalPass
    // },
    // {
    //     path: '/proposalqcreject',
    //     name: 'ProposalReject',
    //     component: ProposalReject
    // },
    // {
    //     path: '/proposalarchieve',
    //     name: 'proposalArchieve',
    //     component: proposalArchieve
    // },
    // {
    //     path: '/proptab',
    //     name: 'propTab',
    //     component: propTab
    // },

    // {
    //     path: '/proposalmaster',
    //     name: 'ProposalMaster',
    //     component: ProposalMaster,
    // },
    // {

    //     path: '/proposalbi',
    //     name: 'proposalbi',

    //     component: ProposalBi
    // },
    // {
    //     path: '/proposaldocupload',
    //     name: 'proposaldocupload',

    //     component: ProposalDocUpload
    // },
    // {
    //     path: '/proposalrecipting',
    //     name: 'proposalrecipting',

    //     component: ProposalRecipting
    // },
    // {
    //     path: '/proposalfulfilment',
    //     name: 'proposalfulfilment',
    //     component: Proposalfulfilment
    // },


    // {
    //     path: '/proposalsumm',
    //     name: 'proposalsumm',
    //     component: proposalSumm
    // },

    // {
    //     path: '/propsummcompo',
    //     name: 'propsummcompo',
    //     component: propSummCompo
    // },

    // {
    //     path: '/table',
    //     name: 'table',
    //     component: Table
    // },
    // {
    //     path: '/addChild',
    //     name: 'AddChild',
    //     component: AddChild,
    // },


    // {
    //     path: '/higherEducation',
    //     name: 'HigherEducation',
    //     component: HigherEducation,
    // },

    // {
    //     path: '/analysiseducation',
    //     name: 'analysiseducation',
    //     component: AnalysisEducation,
    // },

    // {
    //     path: '/slick',
    //     name: 'slick',
    //     component: Slick,
    // },
    // {
    //     path: '/riskquotient',
    //     name: 'riskquotient',
    //     component: RiskQuotient
    // },
    // {
    //     path: '/masterform',
    //     name: 'masterform',
    //     component: MasterPageForm
    // },
    // {
    //     path: '/channel',
    //     name: 'channel',
    //     component: Channel
    // },
    // {
    //     path: '/masterrole',
    //     name: 'masterrole',
    //     component: Rolemaster
    // },
    // {
    //     path: '/affiliatemaster',
    //     name: 'affiliatemaster',
    //     component: AffiliateMaster
    // },

    // {
    //     path: '/documentmaster',
    //     name: 'documentmaster',
    //     component: DocumentMaster
    // },

    // {
    //     path: '/incomemaster',
    //     name: 'incomemaster',
    //     component: IncomeMaster
    // },
    // {
    //     path: '/statecitymaster',
    //     name: 'statecitymaster',
    //     component: StateCityMaster
    // },




    // {
    //     path: '/productmaster',
    //     name: 'ProductMaster',
    //     component: productMaster
    // },
    // {
    //     path: '/usermanagemnt',
    //     component: UserManagement
    // },
    // {
    //     path: '/citycountry',
    //     name: 'citycountry',
    //     component: CityCountry
    // },
    // {
    //     path: '/uploadbill',
    //     name: 'uploadbill',
    //     component: UploadBill
    // },
    // {
    //     path: '/reports',
    //     name: 'reports',
    //     component: Reports
    // },
    // {
    //     path: '/customreports',
    //     name: 'customreports',
    //     component: CustomReports
    // },
    // {
    //     path: '/Rconreports',
    //     name: 'Reconreports',
    //     component: Reconreports
    // },

    // {
    //     path: '/attendancemaster',
    //     name: 'attendancemaster',
    //     component: AttendanceMaster
    // },
    // // Advis0r pitch
    // {
    //     path: '/advisoraboutus',
    //     name: 'advisoraboutus',
    //     component: AdvisorAboutUs
    // },
    // {
    //     path: '/advisorbenefits',
    //     name: 'advisorbenefits',
    //     component: AdvisorBenefits
    // },
    // {
    //     path: '/advisorsuccessstory',
    //     name: 'advisorsuccessstory',
    //     component: AdvisorSuccessStory
    // },

    // {
    //     path: '/campaign',
    //     name: 'campaign',
    //     component: Campaign
    // },
    // {
    //     path: '/subcampaign',
    //     name: 'subcampaign',
    //     component: SubCampaign
    // },
    // {
    //     path: '/activitytracking',
    //     name: 'activitytracking',
    //     component: ActivityTracking
    // },

    // {
    //     path: '/presentationpitch',
    //     name: 'presentationpitch',
    //     component: PresentationPitch
    // },

    // {
    //     path: '/testimonialpitch',
    //     name: 'testimonialpitch',
    //     component: TestimonialsPitch
    // },

    // {
    //     path: '/productpitch',
    //     name: 'productpitch',
    //     component: ProductPitch
    // },
    {
        path: '/usermanagemnt',
        name: 'usermanagemnt',
        component: UserManagemnt
    },

    // {
    //     path: '/userdashbord',
    //     name: 'userdashbord',
    //     component: UserDashbord
    // },
    // {
    //     path: '/productnew',
    //     name: 'productnew',
    //     component: ProductNew
    // },
    // {
    //     path: '/dbclear',
    //     name: 'dbclear',
    //     component: dbClear
    // },

    // {
    //     path: '/insu_admin',
    //     name: 'insu_admin',
    //     component: InsuranceAdmin
    // },

    // {
    //     path: '/traveldetails',
    //     name: 'traveldetails',
    //     component: Traveldetails
    // },

    // {
    //     path: '/informationtab',
    //     name: 'informationtab',
    //     component: InformationTab
    // },

    // {
    //     path: '/pet',
    //     name: 'pet',
    //     component: Pet
    // },

    // {
    //     path: '/petdetails',
    //     name: 'Petinfo',
    //     component: Petinfo
    // },

    // {
    //     path: '/denguedetails',
    //     name: 'Denguedetails',
    //     component: Denguedetails
    // },

    // {
    //     path: '/Dengue',
    //     name: 'Dengue',
    //     component: Dengue
    // },

    // {
    //     path: '/maps',
    //     name: 'maps',
    //     component: Maps
    // },
    // {
    //     // { path: '/', redirect: '/insu_admin' }
    //     path: '/travelinfotab',
    //     name: 'travelinfotab',
    //     component: travelInfoTab
    // },

    // {
    //     path: '/productlist',
    //     name: 'productlist',
    //     component: Productlist

    // },
    // {
    //     path: '/userattendance',
    //     name: 'userattendance',
    //     component: Userattendance

    // },
    // {
    //     path: '/branchdet',
    //     name: 'branchdet',
    //     component: Branchdetails

    // },
    // {
    //     path: '/AccessControl',
    //     name: 'AccessControl',
    //     component: AccessControl

    // },

    // // {
    // //     path: '/NewAccessControl',
    // //     name: 'NewAccessControl',
    // //     component: NewAccessControl

    // // },
    // {
    //     path: '/newdashboard',
    //     name: 'newdashboard',
    //     component: NewDashboard

    // },
    // {
    //     path: '/carbulk',
    //     name: 'carbulk',
    //     component: Carupload

    // },
    // {
    //     path: '/hierarchymaster',
    //     name: 'hierarchymaster',
    //     component: Hierarchymaster

    // },
    // {
    //     path: '/zonemaster',
    //     name: 'zonemaster',
    //     component: Zonemaster

    // },
    // {
    //     path: '/leadtab',
    //     name: 'leadtab',
    //     component: leadTab

    // },
    // // {
    // //     path: '/status',
    // //     name: 'Status',
    // //     component: Status

    // // }, 
    // {
    //     path: '/designation',
    //     name: 'designation',
    //     component: Designation

    // },

    // {
    //     path: '/bankM',
    //     name: 'bankmaster',
    //     component: bankmaster
    // },

    // {   
    //     path: '/banca',
    //     name: 'bancaMaster',
    //     component: bancaMaster
    // },
    // {
    //     path: '/Ltab',
    //     component: Leaddetailstabs,
    //     children: [{
    //             path: 'personalD',
    //             component: PersonalD,
    //         },
    //         {
    //             path: 'contactD',
    //             component: ContactD,
    //         },
    //         {
    //             path: 'proD',
    //             component: ProD,

    //         },
    //         {
    //             path: 'proposedD',
    //             component: ProposedD,

    //         },
    //         {
    //             path: 'existingD',
    //             component: ExistingD,

    //         }
    //     ]

    // },
    // {
    //     path: '/leadhistory',
    //     component: Leadhistory

    // },
    // {
    //     path: '/Lmaster',
    //     name: 'Lmaster',
    //     component: Lmaster,
    //     children: [{
    //             path: 'status',
    //             name: 'status',
    //             component: Status
    //         },
    //         {
    //             path: 'Ltab',
    //             name: 'Ltab',
    //             component: Leaddetailstabs,
    //             children: [{
    //                     path: 'personalD',
    //                     name: 'personalD',
    //                     component: PersonalD,
    //                 },
    //                 {
    //                     path: 'contactD',
    //                     name: 'contactD',
    //                     component: ContactD,
    //                 },
    //                 {
    //                     path: 'proD',
    //                     name: 'proD',
    //                     component: ProD,

    //                 },
    //                 {
    //                     path: 'proposedD',
    //                     name: 'proposedD',
    //                     component: ProposedD,

    //                 },
    //                 {
    //                     path: 'existingD',
    //                     name: 'existingD',
    //                     component: ExistingD,

    //                 }
    //             ]
    //         },
    //         {
    //             path: 'leadhistory',
    //             name: 'leadhistory',
    //             component: Leadhistory

    //         },
    //     ]
    // },
    // {
    //     path: '/emailing',
    //     name: 'emailing',
    //     component: Mailgun

    // },
    // {
    //     path: '/sourcemaster',
    //     name: 'sourcemaster',
    //     component: Sourcemaster

    // },
    // {
    //     path: '/ocmaster',
    //     name: 'ocmaster',
    //     component: Occupmaster

    // },
    // {
    //     path: '/Smaster',
    //     name: 'Smaster',
    //     component: smaster

    // },
    // {
    //     path: '/Campmaster',
    //     name: 'Campmaster',
    //     component: campmaster

    // },
    // {
    //     path: '/custdetails',
    //     name: 'custdetails',
    //     component: Customerdetails

    // },

    // {
    //     path: '/exist',
    //     name: 'existdetails',
    //     component: existdetails

    // },


    // {
    //     path: '/policydetails',
    //     name: 'policydetails',
    //     component: Policydetails
       
    // },
    // {
       
    //     path: '/acc',
    //     name: 'accesstest',
    //     component: accesstest
        
    // },
    // {
       
    //     path: '/reconaccess',
    //     name: 'reconaccess',
    //     component: reconaccess
        
    // },
    // {
        
    //     path: '/rsm',
    //     name: 'resourcentermaster',
    //     component: resourcentermaster
    // },

    {
        
        path: '/rcm',
        name: 'RCCatMaster',
        component: RCCatMaster
    },{
        path:'/job-scheduler',
        name:'JobScheduler',
        component:JobScheduler
    },
    {
        path:'/aigc-policysummary',
        name:'PolicySummaryAigc',
        component:PolicySummaryAigc
    },
    {
        path:'/createuser',
        name: CreateUser,
        component: CreateUser
    },
    {
        path:'/rv-vs-datarep',
        name: RvAndDataRep,
        component: RvAndDataRep
    },
    {
        path:'/excel/bulk-bucket-movement',
        name: ExcelBucketMovement,
        component: ExcelBucketMovement
    },
    {
        path:'/excel/pull-data-from-datarep',
        name: PullDataFromDataRep,
        component: PullDataFromDataRep
    },
     {
        path:'/upload-warranties',
        name:"UploadWarrantiesMop",
        component:UploadWarrantiesMop
    },
    {
        path:'/mapping',
        name:"MappingTest",
        component:MappingTest
    },
    {
        path:'/create-upload-mapping',
        name:"UploadCreateMapping",
        component:UploadCreateMapping
    },

    
    // { path: '/', redirect: '/insu_admin' }


    // { path: '/', redirect: '/travelinfotab' },
    {path:'/',redirect:'/LoginView'},
    {
        path:'/download-reports',
        name: DownloadReports,
        component: DownloadReports
    }
];

// ]





