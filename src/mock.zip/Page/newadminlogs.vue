<template>
    <v-app>
        <!-- <v-content> -->
            <v-card>
             <!-- <v-layout row  justify-space-between class="bgclrcamp bgclrsource pt-3 pl-3 pr-3">
                            <v-flex>
                                <v-btn round depressed medium slot="activator" color="primary" class="ml-0 white--text thebtn" @click.native="addChannel()">
                                    Add New Campaign
                                    <v-icon dark right>add_circle</v-icon>
                                </v-btn>
                                </v-flex>
                            <v-flex xs10 sm6 md2 class="">
                                <v-text-field 
                                @input="Searchdatatable"
                                v-model="value"
                                label="Search" 
                                append-icon="search"
                                height="30px"></v-text-field>                            
                            </v-flex>
             </v-layout> -->
            <v-layout row wrap >
                <v-flex class=" mt-3" style="flex-flow:column wrap">
                    <!-- <v-text class="headline font-weight-bold">Campaign Master</v-text>
                    <hr> -->
                  <v-layout row justify-center>
                    <v-flex justify-center md11 mt-3 >
                        <h3 class="text-xs-center mb-3">Admin Activity Logs</h3>
                        <v-data-table
                        hide-default-footer
                        hide-actions
                        pagination.sync
                        :headers="headers"
                        :items="logsresponse"
                        
                        class="elevation-1">
                        <template slot="items" slot-scope="props">
                             <td > 
                                <span class="status" :style="{color: props.item.campStatus == 'Active' ? '#13961c' : '#d61111'}" >{{props.item.module_name}} </span>
                                <!-- CCAWWP -->
                            </td>
                            <!-- <td class="">{{props.item.code }}</td> -->
                            <td class="">{{props.item.name}}</td>
                            <td > 
                                <!-- <span class="status" :style="{color: props.item.campStatus == 'Active' ? '#13961c' : '#d61111'}" >{{props.item.campStatus}} </span> -->
                                CCAWWP
                            </td>
                            <td class="" style="display:flex; justify-content:center; align-items:center; margin:4px">  -->
                                <!-- <v-layout row justify-center> 
                                     -->
                                    <v-btn small round  @click="openreqres = true" > <v-icon>swap_vert</v-icon> Check Payload </v-btn>
                                     <!--  -->
                                <!-- </v-layout> -->
                            </td>
                           <!-- <td class="">{{props.item.createdDate | formate-date}}</td>
                           <td class="">{{props.item.updatedBy.first_name  == undefined ? "-" : props.item.updatedBy.first_name  +' '+ props.item.updatedBy.last_name}}</td>
                           <td class="">{{props.item.updatedDate | formate-date}}</td> -->

                            <!-- <td class="">
                                <v-icon small class="mr-2" @click="editItem(props.item,props.index)">edit</v-icon> -->
                                <!-- <v-icon small @click="deleteItem(props.item,props.index)">delete</v-icon> -->
                            <!-- </td> -->
                        </template>
                        </v-data-table>
                    </v-flex>


                             
                </v-layout>

                    <v-dialog  v-model="openreqres" persistent max-width="800px" height="500px;" class="dial thepre" style="border-radius: 4px; background-color:red;" >

                    <v-card  style="border-radius:4px;">
                      <v-card class="thepre" style=" z-index: 10; padding:20px; position:fixed; border-radius: 4px; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px; width: 800px;">  
                          
                        <v-btn flat @click="openreqres = false" style="position:absolute; right:0px; top:0px;" small fab> <v-icon> close </v-icon> </v-btn>
                        <v-layout row justify-center>
                                <v-chip ripple   class="chips mr-2" @click="showreq" v-bind:style="{backgroundColor : coloris }" >
                                        <v-avatar left>
                                                <v-img src="/src/assets/up.png"></v-img>
                                        </v-avatar>
                                                Request
                                </v-chip>

                                <v-chip pill  class="chips ml-2"  @click="showres"  v-bind:style="{backgroundColor : coloris2 }" >
                                        <v-avatar left>
                                                <v-img src="/src/assets/down.png"></v-img>
                                        </v-avatar>
                                                Response
                                </v-chip>
                        </v-layout>
                      </v-card>
                        <!-- border-top-right-radius: 0px; border-top-left-radius: 0px -->
                    <v-card class="thepre" style="padding:20px; position:relative; border-radius: 10px;">     
                        
                    <!-- <v-card>

                    </v-card> -->
                     
                    <v-card id="thepre"  v-if="reqcard" style="margin-top: 70px; overflow-wrap: break-word; overflow-x: hidden; padding:10px;" >
                               <pre id="thepre"  >THE {{JSON.stringify(thereqis,  null, '  ')}}
                                </pre>
                    </v-card>
                            <v-card v-if="rescard" style="overflow-wrap: break-word; margin-top: 70px; overflow-x: scroll; padding:10px;">
                                           <pre  cols="100" rows="25" >{{JSON.stringify({  
   "benefitIllustration":{  
      "premium_due_date":"1596868472525",
      "AdvisorName":"shoaib_Jalaluddin khan",
      "AdvisorCode":"AGN293RM",
      "CalculatorType":"Sum Assured to Premium",
      "NameofLifeAssured":"hamid khan",
      "GenderofLifeAssured":"",
      "DateofBirthofLifeAssured":"",
      "ChildName":"",
      "ChildGender":"",
      "ChildDateofBirth":"",
      "RelationshipofChildwithLifeAssured":"",
      "PolicyTerm":"10",
      "PremiumPayingTerm":"",
      "PremiumMode":"Yearly",
      "PremiumType":"Regular",
      "InstallmentPremium":null,
      "MethodofPaymentecs":"",
      "InvestmentOption":"",
      "SumAssured":900000,
      "DeathBenefitOption":"Option 1",
      "AgeProof":"Standard",
      "AnnuityFrequency":"",
      "AnnuityOption":"",
      "DoyouwanttoaddRiderstothisplan":"No",
      "LifeEquityFund3":null,
      "LifePureEquityFund2":null,
      "MakeinIndiaFund":null,
      "LifeBalancedFund1":null,
      "LifeCorporationBondFund1":null,
      "LifeMoneyMarketFund1":null,
      "SmartPensionFund1":null,
      "annualisedPremium":45000,
      "maritalStatus":"",
      "ChildInfo":[  

      ]
   },
   "customerId":null,
   "client_id":null,
   "_Deleted":false,
   "loginDate":1565332472621,
   "_id":"5d4d13c842ee9e3eb7a1cdc4",
   "policyId":"CCAWWP",
   "channelCode":"5d19e62378402c1d059bc54b",
   "userId":{  

   },
   "leadId":{  

   },
   "productId":{  
      "productReasons":{  

      },
      "videoTitle":"",
      "imageTitle":"Fund Performance",
      "active":1,
      "web_link":null,
      "appID":null,
      "_id":"5d3854e620a69964d591bad1",
      "userId":"5b3b4cc28fa96d39870443e3",
      "product_code":"PDDDD75",
      "productCategory":"5d38506920a69964d591bace",
      "productName":"Pacific Select Balanced Fund",
      "productDescription":"Pacific Select Balance Fund aims to provide medium to long-term capital growth and some income by actively allocating its assets among a diversified portfolio of equity and fixed income securities according to market conditions.\n\nAsset Class - Balanced\n\nLatest NAV - MYR 0.4781\n\nFund Size - MYR 4 Million\n\nSector - General\n\nMinimum Initial Investment - MYR 500\n\nMinimum Subsequent Investment  - MYR 100\n\nMinimum RSP Investment - MYR 100\n\nMinimum Redemption Amount - 1000 units\n\nMinimum Holding - 500 units\n\nBuy Processing Time - T + 3 business days\n\nRedemption Processing Time - T + 6 business days\n\nCooling-off Period - Unit Holder can exercise their cooling off right within six (6) business days from the transaction date.\n\n\nCharges\t\nSales Charges - 1.75%\nAnnual Management Fee - 1.50%\nTrustee Fee - 0.07% of the NAV or subject to a minimum of RM18,000 p.a.\nSwitching Fee - nil\nRedemption Fee - nil\nAnnual Expense Ratio - 2.32% as at (Jun 29, 2018)",
      "role_name":"SM1",
      "channelCode":"5d19e62378402c1d059bc54b",
      "productImages":[  

      ],
      "productVideo":[  
         {  

         }
      ],
      "videoLink":"",
      "productBrochure":[  

      ],
      "created_by":"5b3b4cc28fa96d39870443e3",
      "updated_by":"5b3b4cc28fa96d39870443e3",
      "createdDate":"1563972838141",
      "lastupdatedOn":"1564471907354"
   },
   "application_code":"08BE51",
   "proposalStatus":"issued",
   "currentRoute":"/master/masterdoc/cdcdocument",
   "personalDetails":{  

   },
   "nomineeDetails":{  

   },
   "familyhistoryDetails":{  

   },
   "lifeinsuranceDetails":{  

   },
   "medicalDetails":{  

   },
   "detailsOfWitness":{  

   },
   "misc":{  

   },
   "confidentialReport":{  

   },
   "paymentOptions":{  

   },
   "createdDate":1565332424222,
   "documentUpload":[  

   ],
   "cfrdetails":[  

   ],
   "BI_pdf_file":"5497c4543d2885bade5e092e70fc2ac2166cc205.pdf",
   "lastupdatedOn":1565332472526
},  null, '  ')}}
                                </pre>
                            </v-card>


                    <!-- <v-card-actions> -->
                        <!-- <v-spacer></v-spacer>
                        <v-btn depressed large color="grey lighten-3" @click.native=" close()">Cancel
                            <v-icon right dark>highlight_off</v-icon>
                        </v-btn>
                        <v-btn depressed large color="secondary"  :disabled="disbtn" @click.native="saveAndEdit(btnname)">{{btnname}}
                            <v-icon dark right>check_circle</v-icon>
                        </v-btn> -->
                    <!-- </v-card-actions> -->
                    </v-card>
                </v-card>
                    </v-dialog> 

                </v-flex>    
            </v-layout> 
            <div class="text-xs-center pagination" v-if="visible === true">
                              <v-pagination
                                v-model="page"
                                @input="next($event)"
                                :length="pageLength"
                              ></v-pagination>
                    </div> 
            </v-card>
        <!-- </v-content>    -->
   
    </v-app>
</template>
<script>
import axios from 'axios' 

import { required, minLength, between } from 'vuelidate/lib/validators'

var index = 0; // used for put api
export default {

      validations: {
     editedItem: {
        campName: {
            required,
            minLength: minLength(2)
                }
        },
    },

    created(){



              this.$store.commit('SET_PAGE_TITLE','Admin Activity Logs');
            this.GetCampaighn(0);
            let agetdetails = {}
            // agetdetails = this.getAgentInfo()
            // console.log("agentID Check",agetdetails)
          this.uID =  this.getAgentInfo();

           var res = JSON.parse(this.thereqis)
           
           console.log("the OBJECT is->", res );

        //   console.log("THe USer ID IS :::=>>>",this.uID);
    },

    data(){
        return{

          logsresponse:[],

            thereqis:{  
   "benefitIllustration":{  
      "premium_due_date":"1596868472525",
      "AdvisorName":"shoaib_Jalaluddin khan",
      "AdvisorCode":"AGN293RM",
      "CalculatorType":"Sum Assured to Premium",
      "NameofLifeAssured":"hamid khan",
      "GenderofLifeAssured":"",
      "DateofBirthofLifeAssured":"",
      "ChildName":"",
      "ChildGender":"",
      "ChildDateofBirth":"",
      "RelationshipofChildwithLifeAssured":"",
      "PolicyTerm":"10",
      "PremiumPayingTerm":"",
      "PremiumMode":"Yearly",
      "PremiumType":"Regular",
      "InstallmentPremium":null,
      "MethodofPaymentecs":"",
      "InvestmentOption":"",
      "SumAssured":900000,
      "DeathBenefitOption":"Option 1",
      "AgeProof":"Standard",
      "AnnuityFrequency":"",
      "AnnuityOption":"",
      "DoyouwanttoaddRiderstothisplan":"No",
      "LifeEquityFund3":null,
      "LifePureEquityFund2":null,
      "MakeinIndiaFund":null,
      "LifeBalancedFund1":null,
      "LifeCorporationBondFund1":null,
      "LifeMoneyMarketFund1":null,
      "SmartPensionFund1":null,
      "annualisedPremium":45000,
      "maritalStatus":"",
      "ChildInfo":[  

      ]
   },
   "customerId":null,
   "client_id":null,
   "_Deleted":false,
   "loginDate":1565332472621,
   "_id":"5d4d13c842ee9e3eb7a1cdc4",
   "policyId":"CCAWWP",
   "channelCode":"5d19e62378402c1d059bc54b",
   "userId":{  

   },
   "leadId":{  

   },
   "productId":{  
      "productReasons":{  

      },
      "videoTitle":"",
      "imageTitle":"Fund Performance",
      "active":1,
      "web_link":null,
      "appID":null,
      "_id":"5d3854e620a69964d591bad1",
      "userId":"5b3b4cc28fa96d39870443e3",
      "product_code":"PDDDD75",
      "productCategory":"5d38506920a69964d591bace",
      "productName":"Pacific Select Balanced Fund",
      "productDescription":"Pacific Select Balance Fund aims to provide medium to long-term capital growth and some income by actively allocating its assets among a diversified portfolio of equity and fixed income securities according to market conditions.\n\nAsset Class - Balanced\n\nLatest NAV - MYR 0.4781\n\nFund Size - MYR 4 Million\n\nSector - General\n\nMinimum Initial Investment - MYR 500\n\nMinimum Subsequent Investment  - MYR 100\n\nMinimum RSP Investment - MYR 100\n\nMinimum Redemption Amount - 1000 units\n\nMinimum Holding - 500 units\n\nBuy Processing Time - T + 3 business days\n\nRedemption Processing Time - T + 6 business days\n\nCooling-off Period - Unit Holder can exercise their cooling off right within six (6) business days from the transaction date.\n\n\nCharges\t\nSales Charges - 1.75%\nAnnual Management Fee - 1.50%\nTrustee Fee - 0.07% of the NAV or subject to a minimum of RM18,000 p.a.\nSwitching Fee - nil\nRedemption Fee - nil\nAnnual Expense Ratio - 2.32% as at (Jun 29, 2018)",
      "role_name":"SM1",
      "channelCode":"5d19e62378402c1d059bc54b",
      "productImages":[  

      ],
      "productVideo":[  
         {  

         }
      ],
      "videoLink":"",
      "productBrochure":[  

      ],
      "created_by":"5b3b4cc28fa96d39870443e3",
      "updated_by":"5b3b4cc28fa96d39870443e3",
      "createdDate":"1563972838141",
      "lastupdatedOn":"1564471907354"
   },
   "application_code":"08BE51",
   "proposalStatus":"issued",
   "currentRoute":"/master/masterdoc/cdcdocument",
   "personalDetails":{  

   },
   "nomineeDetails":{  

   },
   "familyhistoryDetails":{  

   },
   "lifeinsuranceDetails":{  

   },
   "medicalDetails":{  

   },
   "detailsOfWitness":{  

   },
   "misc":{  

   },
   "confidentialReport":{  

   },
   "paymentOptions":{  

   },
   "createdDate":1565332424222,
   "documentUpload":[  

   ],
   "cfrdetails":[  

   ],
   "BI_pdf_file":"5497c4543d2885bade5e092e70fc2ac2166cc205.pdf",
   "lastupdatedOn":1565332472526
},

            // reqdata:"  ", 
            // resdata:"",
            reqcard:false,
            rescard:false,
            coloris2:"#BBDEFB",
            coloris:"#BBDEFB",
            activeColor:false ,
            openreqres:false,
            page:1,
            skipdiffrence:this.paginationdiff(),
            skip:0,
            disname:false,
            disbtn:false,
            ccode:false,
            dialog: false,
            visible:false,
            skipdiffrence:this.paginationdiff(),
            btnname:'',
            pagination: {},
            pageLength:0,
            skip:0,
            page:1,
            value:'',
            campresponse:[],
            chanelResponse:[],
            // chnelstatus:[],
            editChanel:{},
            editsourceresponse:{},
            TableIndex:'',
            headers:[
                        {text: 'Module Name', value: 'modulename'},
                        {text: 'Date', value: 'codeID'},
                        // {text: 'API Name', value: 'campName'},
                        {text: 'Admin User Name', value: 'admin username'},
                        {text: 'Log description', value:'Logs'},
                        // {text: 'Created Date', value: 'CreatedDate'},
                        // {text: 'Updated By', value: 'UpdatedBy'},
                        // {text: 'Updated Date', value: 'UpdatedDate'},
                        // {text: 'Action', value: 'action', sortable: false}
                ],
            UserID:'',
            tableData: [],
                editedIndex: -1,
                editedItem: {
                campName:'',
                sourceID:'',
                campStatus:'',
                campaignDate:'',
                campcode:'',
               
            },
            defaultItem: {
                campName:'',
                sourceID:'',
                campStatus:'',
                campaignDate:'',
                // branch_name:'',
                // area:'',
                // city_name:'',
                // state_name:'',
                // region_name:'',
                // zone_name:'',
            },
            chnlstatus:['InActive', 'Active'],
            chnlstatusIndex:'',
            editchanneiId:'',
        }
    },
    computed: {
         objmethod() {
        
    	 var self=this;
       return this.campresponse.filter(function(cust){return cust.name.toLowerCase().indexOf(self.value.toLowerCase()) >=0 
        || cust.code.toLowerCase().indexOf(self.value.toLowerCase()) >=0
        || cust.createdBy.first_name.toLowerCase().indexOf(self.value.toLowerCase()) >=0 ||  cust.createdBy.last_name.toLowerCase().indexOf(self.value.toLowerCase()) >=0 || 
         cust.updatedBy.first_name.toLowerCase().indexOf(self.value.toLowerCase()) >=0 ||  cust.updatedBy.last_name.toLowerCase().indexOf(self.value.toLowerCase()) >=0 
          || cust._id.toLowerCase().indexOf(self.value.toLowerCase()) >=0  
       
       
          
         });
       //return this.customers;
    },
        formTitle () {
            return this.editedIndex === -1 ? 'Add' : 'Update'
        },
        popupTitle(){
            return this.editedIndex === -1 ? 'Add New Channel' : 'Edit Channel'
        },

    //      value() {
    //        console.log(this.value);
    //    }
    },

    filters: {

       formateDate(milisecond) {
           try {
               return new Date(parseInt(milisecond)).toLocaleDateString()
           } catch(err) {
               return milisecond;
           }
       }
       ,
        filterid(id, initial) {
           try {
               if (id == null || id == undefined || id == "") { return id; }
               return initial + id.slice(16, 25).toUpperCase();
           } catch (err) { return id; }
       },
   },

    methods:{

   

    showreq(){
          
          this.coloris ="#64B5F6"

          this.coloris2 ="#BBDEFB"
          
          this.reqcard =true
           this.rescard =false
    },

    showres(){
          this.coloris ="#BBDEFB"

          this.coloris2 ="#64B5F6"

          this.reqcard =false
           this.rescard =true
    },


    next(e){
                let skipdata = e - 1
                console.log('data',skipdata)
                if(skipdata === 0 ){
                    this.skip = 0
                }else{
                    this.skip = this.skipdiffrence*skipdata
                }
                console.log('skip data',this.skip)
                this.Getchannel(this.skip)
    },



        checklength(){
                if(this.editedItem.campName.length > 15){
                    this.showToast('Character limit is only 15', this.TOST().WARNING);
                    console.log("greater than 15 ",this.editedItem.campName.length);
                    return
                }
               
        },
        next(e){
                
                let skipdata = e - 1
                console.log('data',skipdata)
                if(skipdata === 0 ){
                    this.skip = 0
                }else{
                    this.skip = this.skipdiffrence*skipdata
                }
                console.log('skip data',this.skip)
                this.GetCampaighn(this.skip)
            },

        Searchdatatable (e) {

            // console.log("value====>>>",e)
                this.value = e;
                // console.log("value is",this.value);
            },


            fetchById(id, rootIndex) {
            // console.log('Fetch By Id : ', rootIndex);
            let self = this;
            this.showLoader(true);
            this.GET('fetch_lead_sources?id='+id, function(res, error) {
            
                if (error) {
                    self.showLoader(false);
                    self.showToast('Something goes wrong', self.TOST().ERROR);
                    console.log('Error ', error);
                    return;
                }
                // When database fails
                if (res.data.errCode == 4) {
                    self.showLoader(false);
                    self.showToast('Database Error', self.TOST().ERROR);
                    return;
                }
                let temp =  self.chanelResponse.splice(0, self.chanelResponse.length);

                self.chanelResponse = [];
                if (res.data.errCode == -1) {
                    res.data.errMsg.forEach((e, index, array) => {
                        temp[rootIndex] = self.mapNewFields(e, rootIndex);
                    });
                    // console.log('Temporray Value : ' , temp);
                    self.chanelResponse = temp.splice(0, temp.length);
                } else {
                    self.showToast('Data not found', self.TOST().INFO);
                }

                self.showLoader(false);
            });
        },

        mapNewFields(e, index) {
                  console.log("New fields for mapping are::=>", e)
            try {
                return {
                    index,
                    _id: e._id,
                    // created_by: e.created_by,
                    // updated_by: e.updated_by,
                    // channelName: e.channelCode.channelName,
                    status: e.status === 1 ? "Active" : "Inactive",
                    // created_by_name: e.created_by.first_name+' '+e.created_by.last_name,
                    // created_date: e.created_date,
                    // updated_by_name: e.updated_by.first_name+' '+e.updated_by.last_name,
                    // updated_date: e.updated_date
                }
            } catch(err) {
                console.log("An error has occured in ")
            }
        },

            GetCampaighn(skip){
            
            //   axios.get('http://172.16.56.36:5010/secure/admin/getlogsAdmin?userId='+this.getAgentInfo()._id).then(
                this.GET('getlogsAdmin?userId='+this.getAgentInfo()._id, res => {
            
            //    res => {
                //  gl99
                //    console.log('GET CHANEL DATA',res.data.errMsg);
                    this.logsresponse = res.data.errMsg
                    // console.log('CHANEL REPONSE',this.chanelResponse)
                    console.log('GET LOGS DATA=>',this.logsresponse);
                    // res.data.errMsg[0].forEach( element => {
                    //     element.campStatus = '';
                    // });
                    // this.campresponse  = []
                    // this.campresponse = res.data.errMsg[0]
                    // console.log('Source REPONSE',this.campresponse)
                        // var pageLen = res.data.errMsg[1]
                        // let totalCount = pageLen[0].totalCount
                        // console.log('Page Length:',totalCount)
                        // this.pageLength = Math.ceil(totalCount/this.skipdiffrence)
                        // if(this.pageLength >1){
                        // this.visible = true
                        //     }else{
                        //         this.visible =false
                        //     }
                    
                    // for( var i=0; i <= this.campresponse.length; i++){
                        // console.log('active==>',this.branchResponse[i].active)
                        // let branchDetails =[]
                    //    console.log("fname is ->",this.campresponse[i])  
                        // this.campaignDate = this.campresponse[i].createdDate;
                       
                        // var thedate = new Date(this.campaignDate);
                        // console.log("The Campaign Date is::=>", thedate.toLocaleDateString());

                        // if(this.campresponse[i].hasOwnProperty('updatedBy') ){
                        //        this.campresponse[i].updatedBy.first_name = this.campresponse[i].updatedBy.first_name
                        //        this.campresponse[i].updatedBy.last_name  = this.campresponse[i].updatedBy.last_name
                        //        this.campresponse[i].updatedDate = this.campresponse[i].updatedDate 
                        //     }else{
                        //     let updatedBy = {
                        //         updatedBy: {
                        //             first_name:" - ",
                        //             last_name:""
                        //         }
                        //     }
                        //     let temp = Object.assign(updatedBy, this.campresponse[i]);

                        //     this.campresponse[i] = temp;
                        //     }


                        // if(this.campresponse[i].status === 1){
                        //     // console.log('active==>',this.branchResponse[i].active)
                        //     this.campresponse[i].campStatus = 'Active'
                           
                        // }else if(this.campresponse[i].status === 0){
                        //     this.campresponse[i].campStatus = 'InActive'
                           
                        // }
                    // }
               }
           ).catch(
               err => {
                   console.log(err) ;
               }
           );
            },
        //  selectchStatus(){
        //     this.chnlstatusIndex = this.chnlstatus.indexOf(this.editedItem.channelStatus)
        //     console.log('select==>',this.chnlstatusIndex)
            
        // },
        saveAndEdit(_btnname){
             if(_btnname == 'Add' )
            {
                this.save();
            } 
            else if(_btnname == 'Update'){
                  
                    this.editChanl();
            }
            },

        addChannel(){
             this.disbtn = false;
            this.disname = false;
            this.ccode = false;
            this.btnname = 'Add';
            this.editedItem.campName = '';
             this.editedItem.campaignDate =''
            if(this.chanelResponse.length === 0){
                this.editedItem.channelCode  ='CH1'
            }else{
            let chanel = this.chanelResponse[0].channelCode
            // console.log('channe;',chanel)
            let constsplitchannel = chanel.split('CH')
            // console.log("Chnel code",(constsplitchannel[1]) )
            let intchnnal = parseInt(constsplitchannel[1])
            this.editedItem.channelCode  ='CH'+(intchnnal+1)
            }
            // this.editedItem.channelCode = '';
            this.editedItem.channelStatus = 'InActive';
            this.dialog = true;
        },


        editItem (item,i) {
             this.disname = true;
             console.log("Data is",item)
            console.log("Index is",i)
            this.TableIndex = i
            // _index = i;
            this.btnname = 'Update' 
            this.ccode=true;
            this.dialog = true;
            var itemssource = item;
            console.log("new item is",itemssource)
            this.editedItem.campcode = itemssource.code;
            this.editedItem.campName = itemssource.name;
            this.editedItem.sourceID = itemssource._id;
            this.editedItem.campStatus = itemssource.status === 1 ? this.chnlstatus[1] : this.chnlstatus[0];        
        },

        editChanl(item){  
                 
            // console.log('CHANNEL CODE',this.editedItem.channelStatus)
            let status = null
            if(this.editedItem.campStatus === 'Active'){
                status = 1
            }else if(this.editedItem.campStatus === 'InActive'){
                status = 0
            }
            console.log('Before PUT',  this.editedItem.campName);
            //  axios.put(this. API_Service_admin() + 'update_campaign',
            //  {              
            //         campName: this.editedItem.campName,
            //         id: this.editedItem.sourceID, 
            //         status: status,                   
            //         userId: this.getAgentInfo()._id,
            //         code: this.editedItem.campcode,

                        
            //  })
            this.PUT('update_campaign',{              
                    campName: this.editedItem.campName,
                    id: this.editedItem.sourceID, 
                    status: status,                   
                    userId: this.getAgentInfo()._id,
                    code: this.editedItem.campcode,

                        
             } , (res , error) => {            

            //  .then(
            //      res => {
                     if(res.data.errCode === -1){
                   console.log('PUT DATABASE RESPONSE',res.data.errMsg);
                    this.editsourceresponse = res.data.errMsg

                //    console.log("Response is from server ",res.data.errMsg);
                 
                  var len = res.data.errMsg.length
                  console.log("After EDIT",len)
                // this.$store.commit('SET_AFFILIATE_DETAILS',this.editsourceresponse);
                //   this.showSnackbar({text: 'Updated Sucessfully',color:'green'})  
                this.showToast('Your Campaign Updated Successfully','success')
                // this.fetchById(); 
                this.GetCampaighn(0);
                    this.dialog = false

                     }else if(res.data.errCode === 428){
                          this.showToast('Campaign code data is mandatory','error')
                     }else{
                        this.showToast('Something went wrong','error')
                     }
               }
           ).catch(
               err => {
                   console.log(err) ;
               }
           );
            // if(this.editChanel.active === 1){
            //         this.channelStatus = 'Active'
            //     }else{
            //          this.channelStatus = 'Inactive'
            //     }

            //      const FormData={
            //         channelName:this.editedItem.chanelName,
            //         _id:this.editedItem.channelCode,
            //          channelStatus:this.editedItem.channelStatus,

            //          }
            //           Object.assign(this.chanelResponse[this.TableIndex], FormData)
          this.disbtn = false;

        },

       

        deleteItem(index) {
        // const index = this.tableData.indexOf(item)
        // this.cfrDataObj.splice(index, 1);
        // confirm('Are you sure you want to delete this item?') && 
        this.chanelResponse.splice(index, 1)
        },

        close () {
        this.dialog = false
        setTimeout(() => {
            this.editedItem = Object.assign({}, this.defaultItem)
            
            this.editedIndex = -1
        }, 300)
        },


        save(){
             this.disbtn = true;
             let self = this;
             // this condition will check for blank spaces only, anything after blank space is valid
            if(/^\s+$/g.test(self.editedItem.campName)){
                        self.showToast('Campaign Name should not be empty', self.TOST().WARNING);
                        this.disbtn = false;
                        return
            }
            else if(self.$v.$invalid == true){
                      self.showToast('Campaign Name should not be empty', self.TOST().WARNING);
                     this.disbtn = false;
            }
            else{
               
                // Post API hit
                // console.log('CHANEL NAME',this.editedItem.channelName),
                console.log('Active InActive ::: ',this.editedItem.campStatus);
                let code = null;
                if(this.editedItem.campStatus === "InActive") {
                    code = 0;
                } else if(this.editedItem.campStatus === "Active") {
                    code = 1;
                }
                let sendData = {
                    campaignName: self.editedItem.campName,
                    userId: this.getAgentInfo()._id ,
                    status: code,
                }

                console.log('POP sending data: ', sendData);
               
            //   axios.post(this. API_Service_admin() + 'create_campaign',sendData).then(
            //         res => {

                this.POST('create_campaign',sendData , (res , error) => {            
                        
                        //    console.log('POST CHANEL DATA',res.data.errMsg);
                        if(res.data.errCode === -1){
                            self.editsourceresponse = res.data.errMsg[0];
                            console.log('Response Data',self.editsourceresponse)
                            self.$store.commit('SET_AFFILIATE_DETAILS',self.editsourceresponse);
                            // self.updateChnl();
                            self.dialog = false    ;
                            
                                // if(self.editChanel.active === 1){
                                //     self.channelStatus = 'Active'
                                // }else{a
                                //     self.channelStatus = 'Inactive'
                                // }
                                
                                // const formData={
                                // channelName :self.editedItem.chanelName,
                                // channel_code: self.editedItem.channelCode,
                                // _id: self.editedItem.channelCode,
                                // channelStatus:self.channelStatus,
                                
                                // }
                                // self.chanelResponse.push(formData)
                                this.showToast('Campaign created Successfully','success');
                                this.GetCampaighn(0);
                                this.disbtn = false;
                        }else{
                           this.disbtn = false;
                           this.showToast('Mandatory fields not found','error');
                        }
                            
                    }
                ).catch(
                    err => {
                        console.log(err) ;
                    }
                );

        }
                // this.close()

               
                },

                // updateChnl(){
                //     let self = this;
                //     self.chanelResponse = self.$store.state.chanelDetails;
                //     console.log('CHNEL RESPONSE',self.chanelResponse)
                // },
     
    }
}
</script>
<style>


#thepre::-webkit-scrollbar-track {
  border-radius: 10px;
  background: rgba(0,0,0,0.1);
  border: 1px solid #ccc;
}

#thepre::-webkit-scrollbar-thumb {
  border-radius: 10px;
  background: linear-gradient(left, #fff, #e4e4e4);
  border: 1px solid #aaa;
}

#thepre::-webkit-scrollbar-thumb:hover {
  background: #fff;
}

#thepre::-webkit-scrollbar-thumb:active {
  background: linear-gradient(left, #22ADD4, #1E98BA);
}






 .dial{
     border-radius: 20px !important ;
 }

 .chips{
     background-color: #BBDEFB;
     box-shadow:0 2px 3px rgba(0,0,0,0.15), 0 2px 3px rgba(0,0,0,0.15);
     cursor: pointer;
     
 }

 /* .chips{
       background-color: #b3e5fc;
     box-shadow:0 2px 3px rgba(0,0,0,0.15), 0 2px 3px rgba(0,0,0,0.15);
      cursor: pointer;
 } */

 /* the line below will make view payload to align center */
 .v-datatable thead th.column.sortable:last-child {
     /* border:2px green dashed; */
     text-align: left !important;
 }

 .status{
    font-family:roboto; font-weight:500; letter-spacing:0.1px;
 }

.bgclrsource{
    background-color: #fafafa;
}
.bgclrcamp{
    background-color: #FAFAFA;
}

    .wrapper-card{
        flex-direction: row;
        flex-wrap: wrap
    }
   .thebtn{
      display:flex;
     align-items:center; 
     color:white;
     border-radius:5px;
     font-size:15px;
    }

    .btn-size{
        width: 1000px
}
     @media screen and (min-width: 320px){

     }
      @media screen and (min-width: 728px){
          .add-branch-btn{
              display: flex;
              justify-content: flex-end;
              margin-right: 15px;
          }
      }
      @media screen and (min-width: 922px){
          .add-branch-btn{
               display: flex;
              justify-content: flex-end;
              margin-right: 15px;              
          }
          .pagination{
            margin-top: 20px;
            }
      }
</style>
