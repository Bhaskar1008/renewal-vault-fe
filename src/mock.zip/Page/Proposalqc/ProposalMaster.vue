<template>
<!-- <div>
    <proposal-tab :tabs="tabs">
    
   
    </proposal-tab>
        <router-view></router-view>
    </div> -->

       <div id="app">
<v-tabs grow light>
<v-tabs-bar>
<v-tabs-item href="/" router>
</v-tabs-item>
</v-tabs-bar>
</v-tabs>

<!-- <router-view /> -->
</div>

</template>
<script>
// import proposalTab from '../Proposalqc/ProposalTab'
export default {
    components:
    {
        // proposalTab
    },

    data(){
        return{
// tabs:[{
//             head:'A',
//             link:"/proposalmaster/proposalbi"
//         },
//         {     head:'B',
//             link:"/proposalmaster/proposaldocupload"
//         },
//         {    head:'C',
//             link:"/proposalmaster/proposalrecipting"
//         }
//          ]
//         }
//          }

}
}
}

</script>
<style>

</style>


