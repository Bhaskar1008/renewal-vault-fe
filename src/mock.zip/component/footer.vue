<template>
    <footer>
        
    </footer>
</template>

<script>
</script>

<style lang="css">
    footer {
        width: 100%;
        height: 50px;
        position: fixed;
        background-color: #F2F2F2;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1), 0 3px 10px rgba(0, 0, 0, 0.05);
        bottom: 0;
        left: 0;
        z-index: 9999;
    }
</style>