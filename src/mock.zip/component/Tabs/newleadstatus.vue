<template>
    
    <div>

        <h1 style="color:#01b4bb; font-family:roboto;">Status Tab</h1>


    </div>

</template>

<script>
export default {
    
}
</script>


<style>


</style>
